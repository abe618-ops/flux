package com.mingyang.flashpush;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Build;
import android.net.Uri;
import android.text.InputType;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int INK = Color.rgb(44, 51, 47);
    private static final int MUTED = Color.rgb(104, 116, 109);
    private static final int ACCENT = Color.rgb(38, 137, 90);
    private static final int BG = Color.rgb(242, 247, 243);
    private static final int MAX_DOWNLOAD_BYTES = 6 * 1024 * 1024;

    private static final Pattern X_STATUS_URL = Pattern.compile(
            "https?://(?:www\\.)?(?:x\\.com|twitter\\.com)/[^\\s/]+/status/\\d+(?:[^\\s]*)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern TELEGRAM_POST_URL = Pattern.compile(
            "https?://(?:www\\.)?(?:t\\.me|telegram\\.me)/(?:s/)?[A-Za-z0-9_]+/\\d+(?:[^\\s]*)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern WECHAT_ARTICLE_URL = Pattern.compile(
            "https?://(?:mp\\.)?weixin\\.qq\\.com/(?:s|mp/appmsg/show)[^\\s<>\"']*",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern ANY_URL = Pattern.compile("https?://[^\\s<>\"']+", Pattern.CASE_INSENSITIVE);

    private EditText editor;
    private EditText emailEditor;
    private TextView status;
    private String lastOriginal = "";
    private String lastTitle = "";
    private String lastSourceUrl = "";
    private String lastHtml = "";
    private int fetchGeneration = 0;
    private boolean clipboardCheckScheduled = false;
    private boolean richShareAutoCloseScheduled = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        buildUi();
        handleIncoming(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncoming(intent);
    }

    @Override protected void onResume() {
        super.onResume();
        if (clipboardCheckScheduled) return;
        clipboardCheckScheduled = true;
        // Android only permits dependable clipboard access while the app is in the foreground.
        getWindow().getDecorView().postDelayed(() -> {
            clipboardCheckScheduled = false;
            tryAutoLoadClipboard();
        }, 280);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = column();
        root.setPadding(dp(20), dp(20), dp(20), dp(28));
        scroll.addView(root, matchWrap());

        LinearLayout titleRow = row();
        TextView title = label("闪记推送", 30, INK, true);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));
        TextView badge = label("系统分享版 v1.5.3", 13, ACCENT, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(round(Color.rgb(235, 249, 241), ACCENT, 22));
        titleRow.addView(badge, new LinearLayout.LayoutParams(dp(132), dp(40)));
        root.addView(titleRow, matchWrap());

        TextView sub = label("支持 X 长推 / Articles、微信公众号全文和前台剪贴板自动载入；可选纯文字或图文 HTML", 14, MUTED, false);
        sub.setLineSpacing(0, 1.2f);
        root.addView(sub, margins(matchWrap(), 0, 3, 0, 12));

        root.addView(label("快捷操作", 15, INK, true), margins(matchWrap(), 0, 0, 0, 7));
        LinearLayout extractRow = row();
        Button paste = button("粘贴提取", Color.WHITE, INK);
        paste.setOnClickListener(v -> pasteAndExtract());
        extractRow.addView(paste, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button clean = button("重新提取", Color.WHITE, INK);
        clean.setOnClickListener(v -> processSharedText(editor.getText().toString(), ""));
        LinearLayout.LayoutParams cleanLp = new LinearLayout.LayoutParams(0, dp(48), 1);
        cleanLp.setMarginStart(dp(8));
        extractRow.addView(clean, cleanLp);
        Button clear = button("清空", Color.WHITE, MUTED);
        clear.setOnClickListener(v -> {
            fetchGeneration++;
            editor.setText(""); lastOriginal = ""; lastTitle = ""; lastSourceUrl = ""; lastHtml = "";
            status.setText("已清空");
        });
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(0, dp(48), 0.72f);
        clearLp.setMarginStart(dp(8));
        extractRow.addView(clear, clearLp);
        root.addView(extractRow, matchWrap());

        LinearLayout sendRow = row();
        Button plainSend = button("纯文字分享", Color.WHITE, ACCENT);
        plainSend.setOnClickListener(v -> pushByEmailChooser(false));
        sendRow.addView(plainSend, new LinearLayout.LayoutParams(0, dp(55), 1));
        Button richSend = button("图文 HTML 分享", ACCENT, Color.WHITE);
        richSend.setOnClickListener(v -> pushByEmailChooser(true));
        LinearLayout.LayoutParams richLp = new LinearLayout.LayoutParams(0, dp(55), 1.25f);
        richLp.setMarginStart(dp(9));
        sendRow.addView(richSend, richLp);
        root.addView(sendRow, margins(matchWrap(), 0, 9, 0, 0));

        status = label("等待接收分享内容", 14, MUTED, false);
        status.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(status, margins(matchWrap(), 2, 8, 2, 10));

        root.addView(label("完整正文预览（发送前可修改）", 16, INK, true), margins(matchWrap(), 0, 0, 0, 8));
        editor = new EditText(this);
        editor.setTextColor(INK);
        editor.setHintTextColor(Color.rgb(150, 166, 156));
        editor.setHint("粘贴网页链接、分享网址或选中的文字…");
        editor.setTextSize(17);
        editor.setGravity(Gravity.TOP | Gravity.START);
        editor.setPadding(dp(16), dp(16), dp(16), dp(16));
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        editor.setMinHeight(dp(300));
        editor.setBackground(round(Color.WHITE, Color.rgb(194, 215, 201), 20));
        root.addView(editor, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(330)));

        Button restore = button("恢复分享原文", Color.TRANSPARENT, ACCENT);
        restore.setOnClickListener(v -> {
            fetchGeneration++;
            if (lastOriginal.isEmpty()) toast("没有可恢复的原文");
            else { editor.setText(lastOriginal); status.setText("已恢复分享时的原文"); }
        });
        root.addView(restore, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        root.addView(label("默认收件邮箱（设置一次即可）", 15, INK, true), margins(matchWrap(), 0, 12, 0, 7));
        LinearLayout emailRow = row();
        emailEditor = new EditText(this);
        emailEditor.setSingleLine(true);
        emailEditor.setTextSize(16);
        emailEditor.setTextColor(INK);
        emailEditor.setHint("例如 name@example.com");
        emailEditor.setHintTextColor(Color.rgb(150, 166, 156));
        emailEditor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        emailEditor.setPadding(dp(13), 0, dp(13), 0);
        emailEditor.setBackground(round(Color.WHITE, Color.rgb(194, 215, 201), 15));
        emailEditor.setText(getPreferences().getString("default_email", ""));
        emailRow.addView(emailEditor, new LinearLayout.LayoutParams(0, dp(50), 1));
        Button saveEmail = button("保存", Color.WHITE, ACCENT);
        saveEmail.setOnClickListener(v -> saveDefaultEmail(true));
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(dp(82), dp(50));
        saveLp.setMarginStart(dp(9));
        emailRow.addView(saveEmail, saveLp);
        root.addView(emailRow, matchWrap());

        TextView note = label("输入框为空时，打开应用会自动读取最近剪贴板并提取；Android 12 以上可能显示系统剪贴板提示。图文 HTML 会保留可获取的格式和图片。邮箱地址仅保存在本机。", 12, MUTED, false);
        note.setGravity(Gravity.CENTER);
        note.setLineSpacing(0, 1.2f);
        root.addView(note, margins(matchWrap(), 8, 12, 8, 0));
        setContentView(scroll);
    }

    private void handleIncoming(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        CharSequence incoming = null;
        if (Intent.ACTION_SEND.equals(action)) incoming = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
        else if (Intent.ACTION_PROCESS_TEXT.equals(action)) incoming = intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
        else return;

        CharSequence subject = intent.getCharSequenceExtra(Intent.EXTRA_SUBJECT);
        if (incoming == null || incoming.toString().trim().isEmpty()) {
            status.setText("没有收到文字；请从网页或帖子中选择“分享”");
            return;
        }
        processSharedText(incoming.toString(), subject == null ? "" : subject.toString());
    }

    private void pasteAndExtract() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) { toast("剪贴板里没有文字"); return; }
        ClipData clip = cm.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) { toast("剪贴板里没有文字"); return; }
        CharSequence value = clip.getItemAt(0).coerceToText(this);
        processSharedText(value == null ? "" : value.toString(), "");
    }

    private void tryAutoLoadClipboard() {
        if (editor == null || editor.length() > 0 || fetchGeneration > 0) return;
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) return;
        ClipDescription description = cm.getPrimaryClipDescription();
        if (isSensitiveClipboard(description)) return;
        ClipData clip = cm.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) return;
        CharSequence value = clip.getItemAt(0).coerceToText(this);
        String text = normalize(value == null ? "" : value.toString());
        if (text.isEmpty() || (firstUrl(ANY_URL, text).isEmpty() && text.length() < 20)) return;
        String fingerprint = Integer.toHexString(text.hashCode()) + ":" + text.length();
        if (fingerprint.equals(getPreferences().getString("last_auto_clipboard", ""))) return;
        getPreferences().edit().putString("last_auto_clipboard", fingerprint).apply();
        status.setText("已自动载入最近剪贴板，正在识别…");
        processSharedText(text, "");
    }

    private static boolean isSensitiveClipboard(ClipDescription description) {
        if (description == null || description.getExtras() == null) return false;
        if (Build.VERSION.SDK_INT >= 33 && description.getExtras().getBoolean(ClipDescription.EXTRA_IS_SENSITIVE, false)) return true;
        return description.getExtras().getBoolean("android.content.extra.IS_SENSITIVE", false);
    }

    private void processSharedText(String raw, String sharedSubject) {
        fetchGeneration++;
        int generation = fetchGeneration;
        raw = normalize(raw);
        if (raw.isEmpty()) { status.setText("没有可处理的文字"); return; }
        lastOriginal = raw;
        lastTitle = cleanTitle(sharedSubject);
        lastSourceUrl = "";
        lastHtml = "";
        editor.setText(raw);

        String xUrl = firstUrl(X_STATUS_URL, raw);
        if (!xUrl.isEmpty()) {
            lastSourceUrl = xUrl;
            String local = cleanXLocally(raw);
            // Share sheets often provide only ~160 visible characters. Always request the full public post.
            fetchX(xUrl, generation, local);
            return;
        }

        String telegramUrl = firstUrl(TELEGRAM_POST_URL, raw);
        if (!telegramUrl.isEmpty()) {
            lastSourceUrl = telegramUrl;
            String local = cleanTelegramLocally(raw);
            if (hasUsefulSharedPost(local)) showResult(local, lastTitle, "已提取 Telegram 分享正文（本机完成）");
            else fetchTelegram(telegramUrl, generation);
            return;
        }

        String wechatUrl = firstUrl(WECHAT_ARTICLE_URL, raw);
        if (!wechatUrl.isEmpty()) {
            lastSourceUrl = wechatUrl;
            fetchWeChat(wechatUrl, generation, cleanTitle(firstNonEmpty(sharedSubject, textWithoutUrls(raw))));
            return;
        }

        String pageUrl = firstUrl(ANY_URL, raw);
        if (!pageUrl.isEmpty()) {
            fetchArticle(pageUrl, generation, cleanTitle(firstNonEmpty(sharedSubject, textWithoutUrls(raw))));
            return;
        }

        showResult(ArticleExtractor.tidy(raw), lastTitle, "已接收选中文字（本机完成）");
    }

    private void fetchX(String postUrl, int generation, String localFallback) {
        beginFetch("正在读取 X 长推 / Article 完整正文…", postUrl);
        new Thread(() -> {
            try {
                Matcher id = Pattern.compile("/status/(\\d+)").matcher(postUrl);
                if (!id.find()) throw new Exception("missing status id");
                String endpoint = "https://api.fxtwitter.com/status/" + id.group(1);
                Download page = download(endpoint, "application/json");
                XPostExtractor.Result result = XPostExtractor.extract(page.body);
                String body = result.text + "\n\n来源：" + postUrl;
                HtmlArchive.Result archive = HtmlArchive.fromWebPage(
                        result.richSourceHtml, postUrl, result.title, result.text, this::downloadImage);
                String kind = result.article ? "X Article" : "X 长推";
                postResult(generation, body, result.title,
                        "已提取" + kind + "完整正文 · " + result.text.length() + " 字 · 图文 " + archive.embeddedImages + " 张", archive.html);
            } catch (Exception e) {
                if (hasUsefulSharedPost(localFallback)) {
                    postResult(generation, localFallback + "\n\n来源：" + postUrl, "X 推文",
                            "完整正文接口暂不可用，当前仅保留分享摘要（请稍后重新提取）", null);
                } else postFailure(generation, "未能读取完整 X 正文；该帖子可能已删除、受限或需要登录");
            }
        }).start();
    }

    private void fetchTelegram(String postUrl, int generation) {
        beginFetch("正在读取公开 Telegram 帖子…", postUrl);
        new Thread(() -> {
            try {
                String cleanUrl = postUrl.replaceAll("[?#].*$", "").replace("/s/", "/");
                Download page = download(cleanUrl + "?embed=1&mode=tme", "text/html");
                ArticleExtractor.Result result = ArticleExtractor.extractTelegram(page.body);
                if (!hasUsefulBody(result.text)) throw new Exception("private or empty");
                postResult(generation, result.text, result.title, "已从 Telegram 公开帖子提取正文", null);
            } catch (Exception e) { postFailure(generation, "未能读取该 Telegram 帖子；私密群、受限内容不支持提取"); }
        }).start();
    }

    private void fetchArticle(String pageUrl, int generation, String fallbackTitle) {
        beginFetch("正在提取网页全文…", pageUrl);
        new Thread(() -> {
            try {
                Download page = download(pageUrl, "text/html,application/xhtml+xml");
                ArticleExtractor.Result result = ArticleExtractor.extractGeneric(page.body);
                if (!hasUsefulBody(result.text) || result.text.length() < 200) throw new Exception("article body too short");
                String title = firstNonEmpty(result.title, fallbackTitle, hostOf(page.finalUrl));
                String body = result.text + "\n\n来源：" + page.finalUrl;
                HtmlArchive.Result archive = HtmlArchive.fromWebPage(
                        page.body, page.finalUrl, title, result.text, this::downloadImage);
                postResult(generation, body, title,
                        "已提取完整正文 · " + result.method + " · " + result.text.length() + " 字 · 图文 " + archive.embeddedImages + " 张", archive.html);
            } catch (Exception e) { postFailure(generation, "未能提取全文；页面可能需要登录、启用脚本或限制访问，已保留原内容"); }
        }).start();
    }

    private void fetchWeChat(String pageUrl, int generation, String fallbackTitle) {
        beginFetch("正在读取微信公众号正文、图注和图片…", pageUrl);
        new Thread(() -> {
            try {
                Download page = download(pageUrl, "text/html,application/xhtml+xml");
                ArticleExtractor.Result result = ArticleExtractor.extractGeneric(page.body);
                if (!hasUsefulBody(result.text) || result.text.length() < 80) throw new Exception("WeChat body too short");
                String title = firstNonEmpty(result.title, fallbackTitle, "微信公众号文章");
                String body = result.text + "\n\n来源：" + page.finalUrl;
                HtmlArchive.Result archive = HtmlArchive.fromWebPage(
                        page.body, page.finalUrl, title, result.text, this::downloadImage);
                postResult(generation, body, title,
                        "已提取微信公众号完整正文 · " + result.text.length() + " 字 · 图文 " + archive.embeddedImages + " 张", archive.html);
            } catch (Exception e) {
                postFailure(generation, "未能读取该公众号全文；文章可能已删除、需要微信验证或限制外部访问，已保留分享内容");
            }
        }).start();
    }

    private void beginFetch(String message, String sourceUrl) {
        lastSourceUrl = sourceUrl;
        editor.setText("");
        status.setText(message);
    }

    private void postResult(int generation, String body, String title, String message, String html) {
        runOnUiThread(() -> {
            if (generation != fetchGeneration) return;
            lastHtml = html == null ? "" : html;
            showResult(body, title, message);
        });
    }

    private void postFailure(int generation, String message) {
        runOnUiThread(() -> {
            if (generation != fetchGeneration) return;
            editor.setText(lastOriginal);
            editor.setSelection(editor.length());
            status.setText(message);
        });
    }

    private void showResult(String body, String title, String message) {
        String clean = ArticleExtractor.tidy(body);
        lastTitle = cleanTitle(firstNonEmpty(title, lastTitle));
        if (lastHtml.isEmpty()) lastHtml = HtmlArchive.fromPlainText(
                firstNonEmpty(lastTitle, "闪记保存"), clean, lastSourceUrl).html;
        editor.setText(clean);
        editor.setSelection(editor.length());
        status.setText(message + " · " + clean.length() + " 字");
    }

    private void pushByEmailChooser(boolean richMedia) {
        String clean = ArticleExtractor.tidy(editor.getText().toString());
        if (clean.isEmpty()) { toast("正文还是空的"); return; }
        if (!saveDefaultEmail(false)) return;
        String recipient = emailEditor.getText().toString().trim();
        editor.setText(clean);
        try {
            String title = firstNonEmpty(lastTitle, "闪记保存");
            Intent send = new Intent(Intent.ACTION_SEND);
            // Keep text/plain as the top-level MIME so Android shows the normal broad share
            // sheet (mail, WeChat, notes, cloud drives, messaging, etc.). The rich HTML file
            // still advertises text/html through its content provider.
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_EMAIL, new String[]{recipient});
            send.putExtra(Intent.EXTRA_SUBJECT, title);
            send.putExtra(Intent.EXTRA_TEXT, clean);
            if (richMedia) {
                if (lastHtml.isEmpty()) lastHtml = HtmlArchive.fromPlainText(title, clean, lastSourceUrl).html;
                File htmlFile = new File(getCacheDir(), HtmlShareProvider.FILE_NAME);
                FileOutputStream output = new FileOutputStream(htmlFile, false);
                output.write(lastHtml.getBytes(StandardCharsets.UTF_8));
                output.close();
                Uri htmlUri = Uri.parse("content://" + HtmlShareProvider.AUTHORITY + "/" + HtmlShareProvider.FILE_NAME);
                // Do not place the full base64-image archive in Intent extras: Binder has a
                // small transaction limit. The complete rich document travels as an attachment.
                send.putExtra(Intent.EXTRA_HTML_TEXT,
                        HtmlArchive.fromPlainText(title, clean, lastSourceUrl).html);
                send.putExtra(Intent.EXTRA_STREAM, htmlUri);
                send.setClipData(ClipData.newRawUri("完整图文 HTML", htmlUri));
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
            openSystemShare(send, richMedia);
            if (richMedia) scheduleAutoCloseAfterRichShare();
            status.setText(richMedia ? "已打开系统分享面板（8秒后自动关闭闪记推送）" : "已打开系统分享面板（纯文字）");
        } catch (Exception e) {
            status.setText("邮件调用失败：" + e.getClass().getSimpleName());
            toast("邮件应用未能打开，已保留正文；可重试或选择系统分享");
        }
    }

    private void openSystemShare(Intent contentIntent, boolean richMedia) {
        String title = richMedia ? "分享完整图文 HTML" : "分享纯文字";
        // No package, component, selector or mailto filter: let Android display every
        // compatible share target and preserve the user's system ranking/defaults.
        Intent broadShare = new Intent(contentIntent);
        broadShare.setPackage(null);
        broadShare.setComponent(null);
        broadShare.setSelector(null);
        startActivity(Intent.createChooser(broadShare, title));
    }

    private void scheduleAutoCloseAfterRichShare() {
        if (richShareAutoCloseScheduled) return;
        richShareAutoCloseScheduled = true;
        // Give the external share target enough time to open and accept the content.
        // Then remove only FlashNotePush from Recents/task history; the third-party
        // mail / messaging app remains open and is not affected.
        getWindow().getDecorView().postDelayed(() -> {
            if (isFinishing()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) finishAndRemoveTask();
            else finish();
        }, 8000L);
    }

    private SharedPreferences getPreferences() {
        return getSharedPreferences("flashnote_settings", MODE_PRIVATE);
    }

    private boolean saveDefaultEmail(boolean showSuccess) {
        String email = emailEditor.getText().toString().trim();
        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailEditor.requestFocus();
            toast("请先输入有效的收件邮箱");
            return false;
        }
        getPreferences().edit().putString("default_email", email).apply();
        if (showSuccess) toast("默认邮箱已保存");
        return true;
    }

    private Download download(String source, String accept) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(source).openConnection();
            connection.setInstanceFollowRedirects(true);
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(18000);
            connection.setRequestProperty("Accept", accept);
            connection.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.7");
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36 FlashNotePush/1.5");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            String type = connection.getContentType();
            if (type != null && !type.toLowerCase(Locale.ROOT).contains("text") && !type.toLowerCase(Locale.ROOT).contains("json")) {
                throw new Exception("unsupported content type");
            }
            byte[] bytes = readLimited(connection.getInputStream(), MAX_DOWNLOAD_BYTES);
            Charset charset = charsetFrom(type);
            return new Download(new String(bytes, charset), connection.getURL().toString());
        } finally { if (connection != null) connection.disconnect(); }
    }

    private HtmlArchive.ImageData downloadImage(String source) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(source).openConnection();
            connection.setInstanceFollowRedirects(true);
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(10000);
            connection.setRequestProperty("Accept", "image/avif,image/webp,image/png,image/jpeg,image/gif,image/*;q=0.8");
            connection.setRequestProperty("Referer", lastSourceUrl);
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36 FlashNotePush/1.5");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            String type = connection.getContentType();
            if (type == null || !type.toLowerCase(Locale.ROOT).startsWith("image/")) throw new Exception("not image");
            byte[] bytes = readLimited(connection.getInputStream(), 2 * 1024 * 1024);
            return new HtmlArchive.ImageData(bytes, type.split(";", 2)[0].trim().toLowerCase(Locale.ROOT));
        } finally { if (connection != null) connection.disconnect(); }
    }

    private static byte[] readLimited(InputStream input, int max) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.min(max, 65536));
        byte[] buffer = new byte[8192];
        int total = 0;
        int count;
        while ((count = input.read(buffer)) != -1) {
            total += count;
            if (total > max) throw new Exception("page too large");
            out.write(buffer, 0, count);
        }
        input.close();
        return out.toByteArray();
    }

    private static Charset charsetFrom(String contentType) {
        if (contentType != null) {
            Matcher matcher = Pattern.compile("(?i)charset=([A-Za-z0-9._-]+)").matcher(contentType);
            if (matcher.find()) try { return Charset.forName(matcher.group(1)); } catch (Exception ignored) { }
        }
        return StandardCharsets.UTF_8;
    }

    private static String cleanXLocally(String raw) {
        Matcher quoted = Pattern.compile("(?is)^.*?(?: on X| on Twitter|在\\s*X\\s*上|在推特上)\\s*[:：]\\s*[\"“](.+)[\"”]\\s*(?:/\\s*(?:X|Twitter|推特))?\\s*(?:https?://\\S+)?\\s*$").matcher(raw);
        if (quoted.matches()) raw = quoted.group(1);
        String text = X_STATUS_URL.matcher(raw).replaceAll("")
                .replaceAll("(?i)https?://t\\.co/\\S+", "")
                .replaceAll("(?i)pic\\.twitter\\.com/\\S+", "");
        List<String> kept = new ArrayList<>();
        for (String value : text.split("\\n")) {
            String line = value.trim();
            String low = line.toLowerCase(Locale.ROOT);
            if (line.matches("^(来自|通过).*(X|Twitter|推特).*$") || line.matches("^(查看|打开|阅读)(推文|帖子|原文|更多).*$")) continue;
            if (low.matches("^(x|twitter|推特)$")) continue;
            if (!line.isEmpty()) kept.add(stripShareQuotes(line));
        }
        return ArticleExtractor.tidy(join(kept));
    }

    private static String cleanTelegramLocally(String raw) {
        String text = TELEGRAM_POST_URL.matcher(raw).replaceAll("");
        List<String> kept = new ArrayList<>();
        for (String value : text.split("\\n")) {
            String line = value.trim();
            if (line.matches("(?i)^(telegram|view in telegram|open in telegram)$") ||
                    line.matches("^(在 Telegram 中查看|打开 Telegram|查看消息)$")) continue;
            if (!line.isEmpty()) kept.add(line);
        }
        return ArticleExtractor.tidy(join(kept));
    }

    private static String textWithoutUrls(String raw) {
        return ArticleExtractor.tidy(ANY_URL.matcher(raw).replaceAll(""));
    }

    private static String firstUrl(Pattern pattern, String raw) {
        Matcher matcher = pattern.matcher(raw);
        return matcher.find() ? trimUrl(matcher.group()) : "";
    }

    private static boolean hasUsefulBody(String text) {
        String without = ANY_URL.matcher(ArticleExtractor.tidy(text)).replaceAll("").trim();
        return without.length() >= 3;
    }

    private static boolean hasUsefulSharedPost(String text) {
        String clean = ANY_URL.matcher(ArticleExtractor.tidy(text)).replaceAll("").trim();
        return clean.length() >= 20 || (clean.contains("\n") && clean.length() >= 6);
    }

    private static String normalize(String text) {
        return ArticleExtractor.tidy(text == null ? "" : text);
    }

    private static String trimUrl(String value) {
        return value.replaceAll("[)）】》>,，。；;!?！？]+$", "");
    }

    private static String stripShareQuotes(String value) {
        return value.replaceFirst("^[\"“]", "").replaceFirst("[\"”]$", "").trim();
    }

    private static String cleanTitle(String title) {
        if (title == null) return "";
        String clean = ArticleExtractor.tidy(title).replaceAll("\\s*\\n\\s*", " ").trim();
        return clean.length() > 100 ? clean.substring(0, 100) : clean;
    }

    private static String hostOf(String url) {
        try { return new URL(url).getHost(); } catch (Exception ignored) { return "网页全文"; }
    }

    private static String firstNonEmpty(String... values) {
        for (String value : values) if (value != null && !value.trim().isEmpty()) return value.trim();
        return "";
    }

    private static String join(List<String> values) {
        StringBuilder out = new StringBuilder();
        for (String value : values) { if (out.length() > 0) out.append('\n'); out.append(value); }
        return out.toString();
    }

    private static final class Download {
        final String body;
        final String finalUrl;
        Download(String body, String finalUrl) { this.body = body; this.finalUrl = finalUrl; }
    }

    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = column(); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private TextView label(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return v;
    }
    private Button button(String s, int bg, int fg) {
        Button b = new Button(this); b.setText(s); b.setTextSize(16); b.setTextColor(fg); b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, bg == Color.TRANSPARENT ? Color.TRANSPARENT : Color.rgb(194, 215, 201), 16));
        return b;
    }
    private GradientDrawable round(int fill, int stroke, int radiusDp) {
        GradientDrawable d = new GradientDrawable(); d.setColor(fill); d.setCornerRadius(dp(radiusDp));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke); return d;
    }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams margins(LinearLayout.LayoutParams p, int l, int t, int r, int b) { p.setMargins(dp(l), dp(t), dp(r), dp(b)); return p; }
    private int dp(int n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
