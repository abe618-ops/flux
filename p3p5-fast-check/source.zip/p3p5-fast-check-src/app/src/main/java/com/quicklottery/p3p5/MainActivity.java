package com.quicklottery.p3p5;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 9001;
    private static final String P3_HTTPS = "https://data.17500.cn/pl3_desc.txt";
    private static final String P5_HTTPS = "https://data.17500.cn/pl5_desc.txt";
    private static final String P3_HTTP = "http://data.17500.cn/pl3_desc.txt";
    private static final String P5_HTTP = "http://data.17500.cn/pl5_desc.txt";

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Random random = new Random();
    private Dataset p3 = new Dataset("排列3", 3);
    private Dataset p5 = new Dataset("排列5", 5);
    private EditText input;
    private TextView status;
    private LinearLayout resultBox;
    private Button queryButton, randomButton, latestButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        loadInitialData();
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        super.onDestroy();
    }

    private View buildUi() {
        int pad = dp(16);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(22), pad, dp(28));
        root.setBackgroundColor(Color.rgb(248, 249, 251));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView title = tv("排3排5 · 开奖速查", 25, Color.rgb(25, 29, 36), true);
        root.addView(title);
        TextView sub = tv("输入日期、期号或直接说一句话，快速找到真实开奖记录", 14, Color.rgb(100, 108, 120), false);
        sub.setPadding(0, dp(5), 0, dp(16));
        root.addView(sub);

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setHint("如 20260703 / 2026年7月3日 / 26174");
        input.setSingleLine(true);
        input.setTextSize(16);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setPadding(dp(14), dp(10), dp(10), dp(10));
        input.setBackground(roundRect(Color.WHITE, Color.rgb(218, 222, 230), 12));
        searchRow.addView(input, new LinearLayout.LayoutParams(0, dp(54), 1f));

        Button mic = button("🎤", Color.rgb(49, 94, 251));
        LinearLayout.LayoutParams micLp = new LinearLayout.LayoutParams(dp(56), dp(54));
        micLp.leftMargin = dp(8);
        searchRow.addView(mic, micLp);
        root.addView(searchRow);

        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doQuery();
                return true;
            }
            return false;
        });
        mic.setOnClickListener(v -> startSpeech());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(12), 0, 0);
        queryButton = button("查询", Color.rgb(35, 43, 58));
        randomButton = button("随机一天", Color.rgb(49, 94, 251));
        latestButton = button("最近一期", Color.rgb(36, 151, 97));
        actions.addView(queryButton, actionLp(1));
        actions.addView(randomButton, actionLp(1));
        actions.addView(latestButton, actionLp(1));
        root.addView(actions);
        queryButton.setOnClickListener(v -> doQuery());
        randomButton.setOnClickListener(v -> showRandom());
        latestButton.setOnClickListener(v -> showLatest());

        status = tv("正在读取本地开奖数据…", 13, Color.rgb(105, 112, 123), false);
        status.setPadding(0, dp(13), 0, dp(8));
        root.addView(status);

        resultBox = new LinearLayout(this);
        resultBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(resultBox, new LinearLayout.LayoutParams(-1, -2));

        TextView foot = tv("数据用于历史开奖查询与核验；安装包内含构建时快照，并会联网尝试更新。", 12, Color.rgb(135, 141, 151), false);
        foot.setPadding(0, dp(22), 0, 0);
        root.addView(foot);
        return scroll;
    }

    private LinearLayout.LayoutParams actionLp(int weight) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), weight);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private void loadInitialData() {
        setEnabled(false);
        io.execute(() -> {
            try {
                SharedPreferences sp = getSharedPreferences("cache", MODE_PRIVATE);
                String p3Text = sp.getString("p3", "");
                String p5Text = sp.getString("p5", "");
                if (p3Text.isEmpty()) p3Text = readAsset("pl3_desc.txt");
                if (p5Text.isEmpty()) p5Text = readAsset("pl5_desc.txt");
                Dataset a = parseText("排列3", 3, p3Text);
                Dataset b = parseText("排列5", 5, p5Text);
                runOnUiThread(() -> {
                    p3 = a; p5 = b;
                    status.setText("已载入：排列3 " + p3.draws.size() + " 期；排列5 " + p5.draws.size() + " 期。正在后台更新…");
                    setEnabled(true);
                    showLatest();
                });
                refreshOnline();
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("本地数据读取失败，可联网后点最近一期重试：" + safeMsg(e));
                    setEnabled(true);
                });
            }
        });
    }

    private void refreshOnline() {
        try {
            String aText = fetchWithFallback(P3_HTTPS, P3_HTTP);
            String bText = fetchWithFallback(P5_HTTPS, P5_HTTP);
            Dataset a = parseText("排列3", 3, aText);
            Dataset b = parseText("排列5", 5, bText);
            if (a.draws.size() < 100 || b.draws.size() < 100) throw new Exception("在线数据条数异常");
            getSharedPreferences("cache", MODE_PRIVATE).edit().putString("p3", aText).putString("p5", bText).apply();
            runOnUiThread(() -> {
                p3 = a; p5 = b;
                status.setText("在线数据已更新：排列3 " + a.draws.size() + " 期；排列5 " + b.draws.size() + " 期");
            });
        } catch (Exception e) {
            runOnUiThread(() -> status.setText("当前使用本地快照；在线更新暂未成功（不影响已缓存查询）"));
        }
    }

    private String fetchWithFallback(String https, String http) throws Exception {
        try { return fetchText(https); } catch (Exception first) { return fetchText(http); }
    }

    private String fetchText(String urlText) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlText).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(25000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 Android P3P5FastCheck/0.1");
        c.setRequestProperty("Accept", "text/plain,*/*");
        c.setInstanceFollowRedirects(true);
        try {
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
                return out.toString(StandardCharsets.UTF_8.name());
            }
        } finally { c.disconnect(); }
    }

    private Dataset parseText(String name, int digits, String text) {
        Dataset ds = new Dataset(name, digits);
        String[] lines = text.split("\\r?\\n");
        for (String line : lines) {
            String s = line.trim();
            if (s.isEmpty()) continue;
            String[] p = s.split("\\s+");
            int min = 2 + digits + 1;
            if (p.length < min || !p[0].matches("\\d{5,8}")) continue;
            String date = normalizeDate(p[1]);
            if (date == null) continue;
            ArrayList<Integer> nums = new ArrayList<>();
            boolean ok = true;
            for (int i = 0; i < digits; i++) {
                Integer v = parseInt(p[2 + i]);
                if (v == null || v < 0 || v > 9) { ok = false; break; }
                nums.add(v);
            }
            if (!ok) continue;
            int salesIndex = 2 + digits;
            Long sales = parseLong(p[salesIndex]);
            ArrayList<Prize> prizes = new ArrayList<>();
            for (int i = salesIndex + 1; i + 1 < p.length; i += 2) {
                Long count = parseLong(p[i]);
                Long amount = parseLong(p[i + 1]);
                if (count == null || amount == null) break;
                prizes.add(new Prize(count, amount));
                if (digits == 3 && prizes.size() >= 3) break;
                if (digits == 5 && prizes.size() >= 1) break;
            }
            Draw d = new Draw(p[0], date, nums, sales, prizes);
            ds.draws.add(d);
            ds.byDate.put(date, d);
            ds.byIssue.put(p[0], d);
        }
        Collections.sort(ds.draws, (x, y) -> {
            int c = y.date.compareTo(x.date);
            return c != 0 ? c : y.issue.compareTo(x.issue);
        });
        return ds;
    }

    private void doQuery() {
        String q = input.getText().toString().trim();
        if (q.isEmpty()) { Toast.makeText(this, "请输入日期、期号或一句话", Toast.LENGTH_SHORT).show(); return; }
        QueryKey key = parseQuery(q);
        if (key == null) {
            Toast.makeText(this, "没有识别到日期或期号，例如：20260703、2026年7月3日、26174", Toast.LENGTH_LONG).show();
            return;
        }
        Draw a, b;
        if (key.date != null) {
            a = p3.byDate.get(key.date); b = p5.byDate.get(key.date);
        } else {
            a = findIssue(p3, key.issue); b = findIssue(p5, key.issue);
        }
        if (a == null && b == null) {
            resultBox.removeAllViews();
            TextView no = tv("没有找到对应开奖记录。若刚开奖，可稍后重新打开应用联网更新。", 16, Color.rgb(160, 58, 58), true);
            no.setPadding(dp(12), dp(16), dp(12), dp(16));
            resultBox.addView(no);
            return;
        }
        showPair(a, b);
    }

    private Draw findIssue(Dataset ds, String issue) {
        Draw d = ds.byIssue.get(issue);
        if (d != null) return d;
        for (Map.Entry<String, Draw> e : ds.byIssue.entrySet()) {
            String k = e.getKey();
            if (k.endsWith(issue) || issue.endsWith(k)) return e.getValue();
            if (k.startsWith("20") && k.substring(2).equals(issue)) return e.getValue();
        }
        return null;
    }

    private void showRandom() {
        List<String> common = commonDates();
        if (common.isEmpty()) { Toast.makeText(this, "当前没有可随机的数据", Toast.LENGTH_SHORT).show(); return; }
        String date = common.get(random.nextInt(common.size()));
        input.setText(date.replace("-", ""));
        showPair(p3.byDate.get(date), p5.byDate.get(date));
    }

    private void showLatest() {
        List<String> common = commonDates();
        if (common.isEmpty()) return;
        String date = common.get(0);
        showPair(p3.byDate.get(date), p5.byDate.get(date));
    }

    private List<String> commonDates() {
        Set<String> common = new HashSet<>(p3.byDate.keySet());
        common.retainAll(p5.byDate.keySet());
        ArrayList<String> dates = new ArrayList<>(common);
        dates.sort(Collections.reverseOrder());
        return dates;
    }

    private void showPair(Draw a, Draw b) {
        resultBox.removeAllViews();
        Draw ref = a != null ? a : b;
        TextView head = tv(ref.date + "    第 " + ref.issue + " 期", 19, Color.rgb(27, 31, 38), true);
        head.setPadding(dp(2), dp(8), 0, dp(8));
        resultBox.addView(head);
        if (a != null) resultBox.addView(drawCard("排列3", a, Color.rgb(49, 94, 251)));
        else resultBox.addView(missingCard("排列3"));
        if (b != null) resultBox.addView(drawCard("排列5", b, Color.rgb(232, 72, 76)));
        else resultBox.addView(missingCard("排列5"));
    }

    private View drawCard(String name, Draw d, int accent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(roundRect(Color.WHITE, Color.rgb(226, 229, 235), 14));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.bottomMargin = dp(10);
        card.setLayoutParams(cardLp);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView n = tv(name, 19, accent, true);
        top.addView(n, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView issue = tv("第" + d.issue + "期", 13, Color.rgb(112, 119, 130), false);
        top.addView(issue);
        card.addView(top);

        TextView balls = tv(joinNums(d.nums), name.equals("排列3") ? 38 : 32, Color.rgb(23, 27, 33), true);
        balls.setLetterSpacing(0.12f);
        balls.setPadding(0, dp(10), 0, dp(8));
        card.addView(balls);

        if (d.sales != null) card.addView(infoLine("销售额", money(d.sales)));
        long total = 0;
        boolean has = false;
        if (name.equals("排列3")) {
            String[] labels = {"直选", "组选3", "组选6"};
            long[] fixed = {1040, 346, 173};
            for (int i = 0; i < labels.length; i++) {
                Prize p = i < d.prizes.size() ? d.prizes.get(i) : null;
                long amount = p != null && p.amount > 0 ? p.amount : fixed[i];
                if (p != null) {
                    has = true;
                    total += p.count * amount;
                    card.addView(infoLine(labels[i], fmt(p.count) + " 注 × " + money(amount)));
                }
            }
        } else {
            Prize p = d.prizes.isEmpty() ? null : d.prizes.get(0);
            long amount = p != null && p.amount > 0 ? p.amount : 100000;
            if (p != null) {
                has = true;
                total += p.count * amount;
                card.addView(infoLine("一等奖", fmt(p.count) + " 注 × " + money(amount)));
            }
        }
        if (has) {
            TextView payout = infoLine("按公开奖级计算派奖", money(total));
            payout.setTypeface(Typeface.DEFAULT_BOLD);
            card.addView(payout);
        }
        return card;
    }

    private View missingCard(String name) {
        TextView t = tv(name + "：该日期未找到开奖记录", 15, Color.rgb(150, 86, 86), false);
        t.setPadding(dp(14), dp(14), dp(14), dp(14));
        t.setBackground(roundRect(Color.WHITE, Color.rgb(235, 220, 220), 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10); t.setLayoutParams(lp);
        return t;
    }

    private TextView infoLine(String left, String right) {
        TextView t = tv(left + "：" + right, 14, Color.rgb(74, 81, 92), false);
        t.setPadding(0, dp(3), 0, dp(3));
        return t;
    }

    private void startSpeech() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "说出日期或期号，例如：2026年7月3日");
            startActivityForResult(i, REQ_SPEECH);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "手机上没有可用的系统语音识别服务", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> list = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (list != null && !list.isEmpty()) {
                input.setText(list.get(0));
                doQuery();
            }
        }
    }

    private QueryKey parseQuery(String raw) {
        String s = toAsciiDigits(raw.trim());
        Matcher compact = Pattern.compile("(?<!\\d)(20\\d{6})(?!\\d)").matcher(s);
        if (compact.find()) {
            String x = compact.group(1);
            String d = x.substring(0,4) + "-" + x.substring(4,6) + "-" + x.substring(6,8);
            if (validDate(d)) return new QueryKey(d, null);
        }
        Matcher date = Pattern.compile("(20\\d{2})\\s*[年./\\-]\\s*(\\d{1,2})\\s*[月./\\-]\\s*(\\d{1,2})\\s*[日号]?").matcher(s);
        if (date.find()) {
            String d = String.format(Locale.US, "%s-%02d-%02d", date.group(1), Integer.parseInt(date.group(2)), Integer.parseInt(date.group(3)));
            if (validDate(d)) return new QueryKey(d, null);
        }
        String cnDate = extractChineseDate(s);
        if (cnDate != null) return new QueryKey(cnDate, null);
        Matcher issue = Pattern.compile("(?<!\\d)(\\d{5,7})(?!\\d)").matcher(s);
        String last = null;
        while (issue.find()) last = issue.group(1);
        if (last != null) return new QueryKey(null, last);
        return null;
    }

    private String extractChineseDate(String s) {
        Matcher m = Pattern.compile("([〇零一二三四五六七八九]{4})年([〇零一二三四五六七八九十]{1,3})月([〇零一二三四五六七八九十]{1,3})[日号]?").matcher(s);
        if (!m.find()) return null;
        Integer y = chineseYear(m.group(1));
        Integer mo = chineseNumber(m.group(2));
        Integer da = chineseNumber(m.group(3));
        if (y == null || mo == null || da == null) return null;
        String d = String.format(Locale.US, "%04d-%02d-%02d", y, mo, da);
        return validDate(d) ? d : null;
    }

    private Integer chineseYear(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            int v = chineseDigit(c); if (v < 0) return null; b.append(v);
        }
        try { return Integer.parseInt(b.toString()); } catch (Exception e) { return null; }
    }

    private Integer chineseNumber(String s) {
        if (s.equals("十")) return 10;
        int pos = s.indexOf('十');
        if (pos >= 0) {
            int tens = pos == 0 ? 1 : chineseDigit(s.charAt(0));
            int ones = pos == s.length() - 1 ? 0 : chineseDigit(s.charAt(pos + 1));
            if (tens < 0 || ones < 0) return null;
            return tens * 10 + ones;
        }
        int n = 0;
        for (char c : s.toCharArray()) { int v = chineseDigit(c); if (v < 0) return null; n = n * 10 + v; }
        return n;
    }

    private int chineseDigit(char c) {
        switch (c) {
            case '〇': case '零': return 0; case '一': return 1; case '二': return 2; case '三': return 3;
            case '四': return 4; case '五': return 5; case '六': return 6; case '七': return 7;
            case '八': return 8; case '九': return 9; default: return -1;
        }
    }

    private String toAsciiDigits(String s) {
        StringBuilder b = new StringBuilder(s.length());
        for (char c : s.toCharArray()) {
            if (c >= '０' && c <= '９') b.append((char)('0' + (c - '０'))); else b.append(c);
        }
        return b.toString();
    }

    private String normalizeDate(String s) {
        String x = s.trim().replace('/', '-').replace('.', '-');
        Matcher m = Pattern.compile("(20\\d{2})-(\\d{1,2})-(\\d{1,2})").matcher(x);
        if (!m.matches()) return null;
        String d = String.format(Locale.US, "%s-%02d-%02d", m.group(1), Integer.parseInt(m.group(2)), Integer.parseInt(m.group(3)));
        return validDate(d) ? d : null;
    }

    private boolean validDate(String d) {
        try {
            int y = Integer.parseInt(d.substring(0,4));
            int m = Integer.parseInt(d.substring(5,7));
            int day = Integer.parseInt(d.substring(8,10));
            if (y < 2004 || y > 2100 || m < 1 || m > 12 || day < 1 || day > 31) return false;
            java.time.LocalDate.of(y, m, day);
            return true;
        } catch (Exception e) { return false; }
    }

    private String readAsset(String name) throws Exception {
        try (InputStream in = getAssets().open(name); BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder b = new StringBuilder(); String line;
            while ((line = r.readLine()) != null) b.append(line).append('\n');
            return b.toString();
        }
    }

    private Long parseLong(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.equals("-") || s.isEmpty()) return null;
        s = s.replace(",", "");
        int dot = s.indexOf('.'); if (dot > 0) s = s.substring(0, dot);
        try { return Long.parseLong(s); } catch (Exception e) { return null; }
    }

    private Integer parseInt(String raw) {
        try { return Integer.parseInt(raw.trim()); } catch (Exception e) { return null; }
    }

    private String joinNums(List<Integer> nums) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < nums.size(); i++) { if (i > 0) b.append("  "); b.append(nums.get(i)); }
        return b.toString();
    }

    private String money(long n) { return fmt(n) + " 元"; }
    private String fmt(long n) { return NumberFormat.getIntegerInstance(Locale.CHINA).format(n); }
    private String safeMsg(Exception e) { return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage(); }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(15); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setGravity(Gravity.CENTER); b.setPadding(dp(5), 0, dp(5), 0);
        b.setBackground(roundRect(color, color, 12));
        return b;
    }

    private TextView tv(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable roundRect(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(dp(radiusDp)); g.setStroke(dp(1), stroke);
        return g;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private void setEnabled(boolean enabled) {
        queryButton.setEnabled(enabled); randomButton.setEnabled(enabled); latestButton.setEnabled(enabled);
    }

    static class Prize { long count, amount; Prize(long c, long a) { count = c; amount = a; } }
    static class Draw {
        String issue, date; List<Integer> nums; Long sales; List<Prize> prizes;
        Draw(String issue, String date, List<Integer> nums, Long sales, List<Prize> prizes) {
            this.issue = issue; this.date = date; this.nums = nums; this.sales = sales; this.prizes = prizes;
        }
    }
    static class Dataset {
        String name; int digits; List<Draw> draws = new ArrayList<>();
        Map<String, Draw> byDate = new HashMap<>(); Map<String, Draw> byIssue = new HashMap<>();
        Dataset(String name, int digits) { this.name = name; this.digits = digits; }
    }
    static class QueryKey { String date, issue; QueryKey(String date, String issue) { this.date = date; this.issue = issue; } }
}
