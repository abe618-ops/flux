
package com.quicklottery.blindbacktest;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.*;
import android.content.res.AssetManager;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private static final String[] GAMES = {"快乐8", "福彩3D", "排列3", "排列5"};
    private static final String[] FILES = {"kl8_desc.txt", "3d_desc.txt", "pl3_desc.txt", "pl5_desc.txt"};
    private static final int[] NEED = {20, 3, 3, 5};

    private LinearLayout root, dynamicBetBox;
    private Spinner gameSpinner, modeSpinner;
    private TextView issueTv, hiddenTv, statusTv, statsTv, dataTv, rulesTv;
    private EditText searchEt, numbersEt, multipleEt;
    private Button lockBtn, revealBtn, prevBtn, nextBtn, randomDrawBtn, randomBetBtn, searchBtn;

    private final ArrayList<Draw> draws = new ArrayList<>();
    private int gameIndex = 0;
    private int currentIndex = 0;
    private Ticket lockedTicket = null;
    private boolean revealed = false;

    private int sessionCount = 0;
    private double totalCost = 0;
    private double totalReturn = 0;
    private int unresolvedFloating = 0;
    private final DecimalFormat moneyFmt = new DecimalFormat("0.##");

    static class Draw {
        String issue;
        String date;
        int[] nums;
        Draw(String issue, String date, int[] nums) { this.issue=issue; this.date=date; this.nums=nums; }
    }
    static class Ticket {
        int game;
        int mode; // KL8: 1..10, digit games: 0 direct, 1 group3, 2 group6
        int[] nums;
        int multiple;
        double cost;
    }
    static class Prize {
        boolean win;
        boolean floating;
        double amountPerBet;
        String label;
        Prize(boolean w, boolean f, double a, String l) { win=w; floating=f; amountPerBet=a; label=l; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        loadGame(0);
    }

    private int dp(int n){ return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView tv(String text, int sp, int color, boolean bold){
        TextView v=new TextView(this); v.setText(text); v.setTextSize(sp); v.setTextColor(color);
        v.setPadding(dp(2),dp(5),dp(2),dp(5)); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v;
    }
    private Button btn(String text){
        Button b=new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(15); return b;
    }
    private LinearLayout row(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void addWeight(View v, LinearLayout parent, float w){
        parent.addView(v,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,w));
    }
    private LinearLayout card(){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14),dp(10),dp(14),dp(10));
        GradientDrawableCompat.setBackground(c, Color.WHITE, dp(10), 0xFFE0E0E0);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(dp(10),dp(7),dp(10),dp(7)); c.setLayoutParams(p); return c;
    }

    private void buildUi(){
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xFFF5F5F5);
        sv.addView(root,new ScrollView.LayoutParams(-1,-2));

        TextView title=tv("四彩 · 历史盲投回测",24,Color.WHITE,true);
        title.setPadding(dp(18),dp(18),dp(18),dp(6));
        TextView sub=tv("先锁定模拟投注，再揭晓真实历史开奖",13,0xFFFFEBEE,false);
        sub.setPadding(dp(18),0,dp(18),dp(14));
        LinearLayout head=new LinearLayout(this); head.setOrientation(LinearLayout.VERTICAL); head.setBackgroundColor(0xFFB71C1C);
        head.addView(title); head.addView(sub); root.addView(head);

        LinearLayout gameCard=card();
        gameCard.addView(tv("① 选择彩种与历史期次",18,0xFF222222,true));
        gameSpinner=new Spinner(this); gameSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,GAMES));
        gameCard.addView(gameSpinner);
        issueTv=tv("",18,0xFFB71C1C,true); gameCard.addView(issueTv);
        hiddenTv=tv("开奖号码：••••••",20,0xFF333333,true); gameCard.addView(hiddenTv);
        LinearLayout nav=row();
        prevBtn=btn("上一期"); nextBtn=btn("下一期"); randomDrawBtn=btn("随机一期");
        addWeight(prevBtn,nav,1); addWeight(nextBtn,nav,1); addWeight(randomDrawBtn,nav,1); gameCard.addView(nav);
        LinearLayout sr=row(); searchEt=new EditText(this); searchEt.setHint("期号或日期，如 20260131"); searchEt.setSingleLine();
        searchBtn=btn("查找"); addWeight(searchEt,sr,2.2f); addWeight(searchBtn,sr,1); gameCard.addView(sr);
        dataTv=tv("",12,0xFF666666,false); gameCard.addView(dataTv); root.addView(gameCard);

        LinearLayout betCard=card();
        betCard.addView(tv("② 先做模拟投注",18,0xFF222222,true));
        dynamicBetBox=new LinearLayout(this); dynamicBetBox.setOrientation(LinearLayout.VERTICAL); betCard.addView(dynamicBetBox);
        LinearLayout br=row(); randomBetBtn=btn("机选"); lockBtn=btn("锁定模拟投注");
        addWeight(randomBetBtn,br,1); addWeight(lockBtn,br,1.7f); betCard.addView(br);
        root.addView(betCard);

        LinearLayout revealCard=card();
        revealCard.addView(tv("③ 一键揭晓并判奖",18,0xFF222222,true));
        revealBtn=btn("查看是否中奖"); revealBtn.setEnabled(false); revealCard.addView(revealBtn);
        statusTv=tv("先完成上方模拟投注。",16,0xFF444444,false); revealCard.addView(statusTv);
        root.addView(revealCard);

        LinearLayout statCard=card();
        statCard.addView(tv("回测统计",18,0xFF222222,true));
        statsTv=tv("",16,0xFF222222,false); statCard.addView(statsTv);
        root.addView(statCard);

        LinearLayout ruleCard=card();
        ruleCard.addView(tv("规则口径",18,0xFF222222,true));
        rulesTv=tv("",13,0xFF555555,false); ruleCard.addView(rulesTv);
        ruleCard.addView(tv("仅用于历史数据学习与回测，不接入真实购买、支付或下单。",12,0xFF777777,false));
        root.addView(ruleCard);

        setContentView(sv);
        updateStats();

        gameSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id){ if(pos!=gameIndex || draws.isEmpty()) loadGame(pos); }
        });
        prevBtn.setOnClickListener(v->{ if(!draws.isEmpty()){ currentIndex=Math.min(draws.size()-1,currentIndex+1); setDraw(); }});
        nextBtn.setOnClickListener(v->{ if(!draws.isEmpty()){ currentIndex=Math.max(0,currentIndex-1); setDraw(); }});
        randomDrawBtn.setOnClickListener(v->{ if(!draws.isEmpty()){ currentIndex=new Random().nextInt(draws.size()); setDraw(); }});
        searchBtn.setOnClickListener(v->searchDraw());
        randomBetBtn.setOnClickListener(v->randomBet());
        lockBtn.setOnClickListener(v->lockTicket());
        revealBtn.setOnClickListener(v->reveal());
    }

    private void buildBetControls(){
        dynamicBetBox.removeAllViews();
        modeSpinner=new Spinner(this);
        if(gameIndex==0){
            String[] a=new String[10]; for(int i=0;i<10;i++) a[i]="选"+cn(i+1)+"（"+(i+1)+"个号码）";
            modeSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a));
        } else if(gameIndex==3) {
            modeSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"直选"}));
        } else {
            modeSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"直选/单选","组选3","组选6"}));
        }
        dynamicBetBox.addView(modeSpinner);
        numbersEt=new EditText(this);
        numbersEt.setSingleLine(false);
        numbersEt.setMinLines(2);
        numbersEt.setHint(gameIndex==0 ? "输入号码，如 03 17 28（数量按玩法）" : (gameIndex==3 ? "输入5位号码，如 01357" : "输入3位号码，如 012"));
        dynamicBetBox.addView(numbersEt);
        LinearLayout mr=row(); mr.addView(tv("倍数：",15,0xFF333333,false));
        multipleEt=new EditText(this); multipleEt.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); multipleEt.setText("1"); multipleEt.setSingleLine();
        mr.addView(multipleEt,new LinearLayout.LayoutParams(dp(100),-2)); dynamicBetBox.addView(mr);
    }

    private void loadGame(int idx){
        gameIndex=idx; draws.clear(); currentIndex=0; lockedTicket=null; revealed=false;
        buildBetControls();
        try{
            String raw=readAsset(FILES[idx]);
            parseHistory(raw, idx);
        }catch(Exception e){
            statusTv.setText("历史数据载入失败："+e.getMessage());
        }
        if(draws.isEmpty()){
            issueTv.setText(GAMES[idx]+"：暂无历史快照");
            hiddenTv.setText("开奖号码：—");
            dataTv.setText("构建时数据快照缺失。请重新运行 GitHub Actions 构建。");
        }else{
            Collections.sort(draws,(a,b)->{
                int c=b.date.compareTo(a.date); return c!=0?c:b.issue.compareTo(a.issue);
            });
            setDraw();
            dataTv.setText("已载入 "+draws.size()+" 期真实历史记录 · 数据快照随 APK 构建同步");
        }
        setRules();
    }

    private String readAsset(String name) throws IOException{
        InputStream in=getAssets().open(name); ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n); in.close();
        return out.toString("UTF-8");
    }

    private void parseHistory(String raw, int game){
        HashSet<String> seen=new HashSet<>();
        String[] lines=raw.split("\\r?\\n");
        for(String line:lines){
            Draw d=parseLine(line, game);
            if(d!=null && seen.add(d.issue+"|"+d.date)) draws.add(d);
        }
    }

    private Draw parseLine(String line, int game){
        line=line.trim(); if(line.length()<5) return null;
        String date="";
        Matcher dm=Pattern.compile("(20\\d{2})[-/年\\.](\\d{1,2})[-/月\\.](\\d{1,2})").matcher(line);
        if(dm.find()) date=String.format(Locale.US,"%s-%02d-%02d",dm.group(1),Integer.parseInt(dm.group(2)),Integer.parseInt(dm.group(3)));
        if(date.length()==0){
            Matcher d8=Pattern.compile("(?<!\\d)(20\\d{6})(?!\\d)").matcher(line);
            if(d8.find()){
                String s=d8.group(1); date=s.substring(0,4)+"-"+s.substring(4,6)+"-"+s.substring(6,8);
            }
        }
        String clean=line.replaceAll("[,，;；|\\t]+"," ");
        String[] tok=clean.split("\\s+");
        String issue="";
        int issuePos=-1;
        for(int i=0;i<Math.min(tok.length,5);i++){
            String t=tok[i].replaceAll("\\D","");
            if(t.matches("\\d{5,9}") && !(t.length()==8 && t.startsWith("20"))){ issue=t; issuePos=i; break; }
        }
        if(issue.length()==0){
            Matcher im=Pattern.compile("(?<!\\d)(\\d{5,9})(?!\\d)").matcher(line);
            while(im.find()){
                String s=im.group(1);
                if(!(s.length()==8 && s.startsWith("20"))){ issue=s; break; }
            }
        }
        if(issue.length()==0 || date.length()==0) return null;

        int need=NEED[game];
        ArrayList<Integer> vals=new ArrayList<>();
        boolean passedIssue=false, passedDate=false;
        for(int i=0;i<tok.length;i++){
            String t=tok[i].trim();
            if(t.equals(issue) || (issuePos==i)){ passedIssue=true; continue; }
            if(t.matches("20\\d{2}[-/年\\.]\\d{1,2}[-/月\\.]\\d{1,2}.*") || t.equals(date.replace("-",""))){ passedDate=true; continue; }
            if(!passedIssue) continue;
            // Most source files place date before the draw numbers. If date is embedded with weekday, allow after issue too.
            String digits=t.replaceAll("\\D","");
            if(game>0 && digits.length()==need && t.matches("\\d+")){
                vals.clear();
                for(char c:digits.toCharArray()) vals.add(c-'0');
                break;
            }
            if(t.matches("\\d{1,2}")){
                int x=Integer.parseInt(t);
                if(game==0){
                    if(x>=1 && x<=80) vals.add(x);
                }else{
                    if(x>=0 && x<=9) vals.add(x);
                }
                if(vals.size()==need) break;
            }
        }
        if(vals.size()<need){
            // fallback: scan substring after the detected date, then take first plausible values
            int p=line.indexOf(date.substring(0,4));
            String sub=p>=0?line.substring(p):line;
            Matcher nm=Pattern.compile("(?<!\\d)(\\d{1,2})(?!\\d)").matcher(sub);
            vals.clear();
            while(nm.find() && vals.size()<need){
                int x=Integer.parseInt(nm.group(1));
                if(game==0 && x>=1 && x<=80) vals.add(x);
                else if(game>0 && x>=0 && x<=9) vals.add(x);
            }
        }
        if(vals.size()!=need) return null;
        if(game==0 && new HashSet<Integer>(vals).size()!=20) return null;
        int[] nums=new int[need]; for(int i=0;i<need;i++) nums[i]=vals.get(i);
        return new Draw(issue,date,nums);
    }

    private void setDraw(){
        lockedTicket=null; revealed=false; revealBtn.setEnabled(false); lockBtn.setEnabled(true);
        if(draws.isEmpty()) return;
        Draw d=draws.get(currentIndex);
        issueTv.setText(GAMES[gameIndex]+" · 第"+d.issue+"期 · "+d.date);
        hiddenTv.setText("开奖号码：已隐藏");
        statusTv.setText("请先选择玩法和号码，然后锁定模拟投注。");
        if(numbersEt!=null) numbersEt.setText("");
    }

    private void searchDraw(){
        String q=searchEt.getText().toString().trim().replace("年","-").replace("月","-").replace("日","");
        String d=q.replaceAll("[^0-9]","");
        for(int i=0;i<draws.size();i++){
            Draw x=draws.get(i);
            String dd=x.date.replace("-","");
            if(x.issue.equals(d) || x.issue.equals(q) || dd.equals(d) || x.date.equals(q)){
                currentIndex=i; setDraw(); hideKeyboard(); return;
            }
        }
        Toast.makeText(this,"未找到对应期号/日期",Toast.LENGTH_SHORT).show();
    }

    private void randomBet(){
        Random r=new Random();
        if(gameIndex==0){
            int n=modeSpinner.getSelectedItemPosition()+1;
            TreeSet<Integer> s=new TreeSet<>(); while(s.size()<n) s.add(1+r.nextInt(80));
            StringBuilder b=new StringBuilder(); for(int x:s){ if(b.length()>0)b.append(" "); b.append(String.format(Locale.US,"%02d",x)); }
            numbersEt.setText(b.toString());
        }else{
            int n=gameIndex==3?5:3;
            StringBuilder b=new StringBuilder();
            int mode=modeSpinner.getSelectedItemPosition();
            if(gameIndex!=3 && mode==1){
                int a=r.nextInt(10), c; do{c=r.nextInt(10);}while(c==a);
                int[] z={a,a,c}; shuffle(z,r); for(int x:z)b.append(x);
            } else if(gameIndex!=3 && mode==2){
                ArrayList<Integer> z=new ArrayList<>(); while(z.size()<3){int x=r.nextInt(10);if(!z.contains(x))z.add(x);}
                Collections.shuffle(z,r); for(int x:z)b.append(x);
            } else {
                for(int i=0;i<n;i++) b.append(r.nextInt(10));
            }
            numbersEt.setText(b.toString());
        }
    }

    private void shuffle(int[] a,Random r){ for(int i=a.length-1;i>0;i--){int j=r.nextInt(i+1),t=a[i];a[i]=a[j];a[j]=t;} }

    private void lockTicket(){
        if(draws.isEmpty()) return;
        try{
            int mult=Integer.parseInt(multipleEt.getText().toString().trim());
            int max=gameIndex==0?15:99;
            if(mult<1 || mult>max) throw new IllegalArgumentException("倍数须为1-"+max);
            Ticket t=new Ticket(); t.game=gameIndex; t.multiple=mult; t.cost=2.0*mult;
            if(gameIndex==0){
                int n=modeSpinner.getSelectedItemPosition()+1; t.mode=n;
                t.nums=parseHappy(numbersEt.getText().toString(),n);
            }else{
                int n=gameIndex==3?5:3; t.mode=modeSpinner.getSelectedItemPosition();
                t.nums=parseDigits(numbersEt.getText().toString(),n);
                if(gameIndex!=3 && t.mode==1 && pattern(t.nums)!=2) throw new IllegalArgumentException("组选3必须恰有两个相同数字");
                if(gameIndex!=3 && t.mode==2 && pattern(t.nums)!=3) throw new IllegalArgumentException("组选6必须三个数字各不相同");
            }
            lockedTicket=t; revealed=false; revealBtn.setEnabled(true); lockBtn.setEnabled(false);
            totalCost+=t.cost; sessionCount++;
            statusTv.setText("已锁定：¥"+moneyFmt.format(t.cost)+"。现在可点击“查看是否中奖”。");
            updateStats(); hideKeyboard();
        }catch(Exception e){ Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private int[] parseHappy(String s,int n){
        Matcher m=Pattern.compile("\\d{1,2}").matcher(s);
        ArrayList<Integer> a=new ArrayList<>(); HashSet<Integer> seen=new HashSet<>();
        while(m.find()){ int x=Integer.parseInt(m.group()); if(x<1||x>80) throw new IllegalArgumentException("快乐8号码须为01-80"); if(!seen.add(x)) throw new IllegalArgumentException("号码不可重复"); a.add(x); }
        if(a.size()!=n) throw new IllegalArgumentException("当前玩法必须选择"+n+"个号码");
        int[] r=new int[n]; for(int i=0;i<n;i++)r[i]=a.get(i); return r;
    }
    private int[] parseDigits(String s,int n){
        String d=s.replaceAll("\\D","");
        if(d.length()!=n) throw new IllegalArgumentException("请输入恰好"+n+"位数字");
        int[] r=new int[n]; for(int i=0;i<n;i++)r[i]=d.charAt(i)-'0'; return r;
    }
    private int pattern(int[] a){
        HashSet<Integer> s=new HashSet<>(); for(int x:a)s.add(x); return s.size()==1?1:(s.size()==2?2:3);
    }

    private void reveal(){
        if(lockedTicket==null || revealed || draws.isEmpty()) return;
        revealed=true; Draw d=draws.get(currentIndex);
        hiddenTv.setText("开奖号码："+formatDraw(d));
        Prize p=settle(lockedTicket,d);
        if(p.floating){
            unresolvedFloating++;
            statusTv.setText("命中 "+p.label+"（浮动奖）。为保证历史回测准确，本版不以封顶值代替当期实际奖金；该笔暂不计入收益率。");
        }else{
            double ret=p.amountPerBet*lockedTicket.multiple;
            totalReturn+=ret;
            if(p.win) statusTv.setText("中奖："+p.label+"，本次模拟返奖 ¥"+moneyFmt.format(ret));
            else statusTv.setText("未中奖。本次模拟返奖 ¥0");
        }
        revealBtn.setEnabled(false); updateStats();
    }

    private String formatDraw(Draw d){
        if(gameIndex==0){
            StringBuilder b=new StringBuilder(); for(int x:d.nums){if(b.length()>0)b.append(" ");b.append(String.format(Locale.US,"%02d",x));} return b.toString();
        }
        StringBuilder b=new StringBuilder(); for(int x:d.nums)b.append(x); return b.toString();
    }

    private Prize settle(Ticket t,Draw d){
        if(t.game==0) return settleHappy(t,d);
        if(t.game==3){
            boolean ok=Arrays.equals(t.nums,d.nums); return new Prize(ok,false,ok?100000:0,ok?"一等奖":"未中奖");
        }
        if(t.mode==0){
            boolean ok=Arrays.equals(t.nums,d.nums); return new Prize(ok,false,ok?1040:0,ok?(t.game==1?"单选":"直选"):"未中奖");
        }
        int pt=pattern(d.nums);
        int[] a=t.nums.clone(), b=d.nums.clone(); Arrays.sort(a); Arrays.sort(b);
        boolean same=Arrays.equals(a,b);
        if(t.mode==1){boolean ok=pt==2&&same;return new Prize(ok,false,ok?346:0,ok?"组选3":"未中奖");}
        boolean ok=pt==3&&same;return new Prize(ok,false,ok?173:0,ok?"组选6":"未中奖");
    }

    private Prize settleHappy(Ticket t,Draw d){
        HashSet<Integer> win=new HashSet<>(); for(int x:d.nums)win.add(x);
        int hit=0; for(int x:t.nums)if(win.contains(x))hit++;
        boolean newer = d.date.compareTo("2025-12-30")>=0;
        int n=t.mode;
        // Floating levels must use the draw-specific official prize notice, never the cap as a substitute.
        if(n==10 && hit==10) return new Prize(true,true,0,"选十中十");
        if(newer && n==9 && hit==9) return new Prize(true,true,0,"选九中九");
        double a=happyFixed(newer,n,hit);
        String label=a>0?("选"+cn(n)+"中"+cn(hit)+(hit==0?"（全不中）":"")):"未中奖";
        return new Prize(a>0,false,a,label);
    }

    private double happyFixed(boolean n,int k,int h){
        if(n){
            switch(k){
                case 10: if(h==9)return 8000;if(h==8)return 720;if(h==7)return 80;if(h==6)return 5;if(h==5)return 3;if(h==0)return 2;break;
                case 9: if(h==8)return 2000;if(h==7)return 225;if(h==6)return 22;if(h==5)return 5;if(h==4)return 3;if(h==0)return 2;break;
                case 8: if(h==8)return 50000;if(h==7)return 800;if(h==6)return 80;if(h==5)return 10;if(h==4)return 3;if(h==0)return 2;break;
                case 7: if(h==7)return 8500;if(h==6)return 300;if(h==5)return 30;if(h==4)return 4;if(h==0)return 2;break;
                case 6: if(h==6)return 2880;if(h==5)return 30;if(h==4)return 10;if(h==3)return 3;break;
                case 5: if(h==5)return 1000;if(h==4)return 20;if(h==3)return 3;break;
                case 4: if(h==4)return 93;if(h==3)return 5;if(h==2)return 3;break;
                case 3: if(h==3)return 52;if(h==2)return 3;break;
                case 2: if(h==2)return 19;break;
                case 1: if(h==1)return 4.5;break;
            }
        }else{
            switch(k){
                case 10: if(h==9)return 8000;if(h==8)return 800;if(h==7)return 80;if(h==6)return 5;if(h==5)return 3;if(h==0)return 2;break;
                case 9: if(h==9)return 300000;if(h==8)return 2000;if(h==7)return 200;if(h==6)return 20;if(h==5)return 5;if(h==4)return 3;if(h==0)return 2;break;
                case 8: if(h==8)return 50000;if(h==7)return 800;if(h==6)return 88;if(h==5)return 10;if(h==4)return 3;if(h==0)return 2;break;
                case 7: if(h==7)return 10000;if(h==6)return 288;if(h==5)return 28;if(h==4)return 4;if(h==0)return 2;break;
                case 6: if(h==6)return 3000;if(h==5)return 30;if(h==4)return 10;if(h==3)return 3;break;
                case 5: if(h==5)return 1000;if(h==4)return 21;if(h==3)return 3;break;
                case 4: if(h==4)return 100;if(h==3)return 5;if(h==2)return 3;break;
                case 3: if(h==3)return 53;if(h==2)return 3;break;
                case 2: if(h==2)return 19;break;
                case 1: if(h==1)return 4.6;break;
            }
        }
        return 0;
    }

    private void updateStats(){
        double net=totalReturn-totalCost;
        String roi=totalCost>0?new DecimalFormat("0.00").format(net/totalCost*100)+"%":"—";
        String s="模拟票数："+sessionCount+"  ·  累计投入：¥"+moneyFmt.format(totalCost)+"\n"
                +"已核算返奖：¥"+moneyFmt.format(totalReturn)+"  ·  净收益：¥"+moneyFmt.format(net)+"\n"
                +"ROI："+roi;
        if(unresolvedFloating>0) s+="\n浮动奖待当期开奖公告核算："+unresolvedFloating+"笔（未计入返奖/ROI）";
        statsTv.setText(s);
    }

    private void setRules(){
        if(gameIndex==0){
            rulesTv.setText("快乐8：01-80中选择1至10个号码，每注2元；每期摇出20个号码。2025-12-30（第2025350期）起按新规则结算：选九中九与选十中十为浮动奖，其他奖级按新固定奖表；更早期次按旧规则结算。");
        }else if(gameIndex==1){
            rulesTv.setText("福彩3D：000-999，单选/组选3/组选6每注2元；本工具首版支持这三种核心玩法。固定奖：单选1040元、组选3为346元、组选6为173元。");
        }else if(gameIndex==2){
            rulesTv.setText("排列3：000-999，每注2元；直选1040元、组选3为346元、组选6为173元。排列3开奖号码取同期排列5开奖号码前三位。");
        }else{
            rulesTv.setText("排列5：00000-99999，每注2元；本工具按直选结算，5位号码与开奖号码顺序完全一致中一等奖，单注固定奖金100000元。");
        }
    }

    private String cn(int n){
        String[] c={"零","一","二","三","四","五","六","七","八","九","十"}; return n>=0&&n<c.length?c[n]:String.valueOf(n);
    }
    private void hideKeyboard(){
        View v=getCurrentFocus(); if(v!=null)((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);
    }

    // Small helper avoids requiring AndroidX/CardView.
    static class GradientDrawableCompat {
        static void setBackground(View v,int fill,int radius,int stroke){
            android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();
            g.setColor(fill);g.setCornerRadius(radius);g.setStroke(1,stroke);v.setBackground(g);
        }
    }
}
